# csl7520-project-srigowri-nikhil
csl7520-project-srigowri-nikhil created by GitHub Classroom


#Download the data from movielens
#place it in data folder and run scripts/cuda_automate.sh
